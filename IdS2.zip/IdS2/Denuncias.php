<?php

require 'BASE.php';

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Denuncias y Reportes Gubernamentales</title>
    <link rel="stylesheet" href="denuncias.css">
  </head>
  <body>
    <header>
      <h1>Denuncias y Reportes Gubernamentales</h1>
    </header>
    <nav>
      <ul>
        <li><a href="#">Denuncias</a></li>
        <li><a href="#">Reportes</a></li>
        <li><a href="#">Consultas</a></li>
        <li><a href="#">Contacto</a></li>
      </ul>
    </nav>
    <main>
      <h2>Realizar una denuncia</h2>
      <form action="#" method="post">
        <label for="nombre">Nombre completo:</label>
        <input type="text" id="nombre" name="nombre" required>

        <label for="email">Correo electrónico:</label>
        <input type="email" id="email" name="email" required>

        <label for="denuncia">Denuncia:</label>
        <textarea id="denuncia" name="denuncia" rows="10" required></textarea> 
        <label for="archivo">Adjuntar archivo:</label>
        <input type="file" id="archivo" name="archivo">
<br></br>

        <input type="submit" value="Enviar denuncia">
      </form>
    </main>
    <footer>
<script src="denuncias.js"></script>
      <p>© 2023 Gobierno de Mexico</p>
    </footer>
  </body>
</html>
