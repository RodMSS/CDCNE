<?php

  session_start();
  require 'BASE.php';

  if (!empty($_POST['username']) && !empty($_POST['password'])) {
    $records = $conn->prepare('SELECT id, username, email, password FROM registros WHERE username = :username');
    $records->bindParam(':username', $_POST['username']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $message = '';

    if (is_countable($results) && count($results) > 0 && ($_POST['password'] == $results['password'])) {
      $_SESSION['user_id'] = $results['id'];
		$message = "Login exitoso";
		header('Location: http://localhost/IdS2/menudenuncias.html');
    } else {
      $message = 'Usuario no registrado';
    }
  }

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
 <title>Formulario de inicio de sesión</title>
 <link rel="stylesheet" type="text/css" href="frm.css">
</head>
<body>
	
 <table class="center">
  <tr>
   <td>
    <div class="login-form">
     <h2>Iniciar sesión</h2>
     <form action="forma.php" method="POST">
      <input type="text" id="username" name="username" placeholder="Ingresa tu nombre de usuario" style="width :96%;" required>
      <input type="password" id="password" name="password" placeholder="Ingresa tu contraseña" style="width :96%;" required>       
      <center><input type="submit" value="Iniciar sesión"> 
		 <h4> ¿No tienes una cuenta? </h4>
		  <h3><a href= "http://localhost/IdS2/registro.php"> Registrate </a></h3>
		  </center>
		 	<?php if(!empty($message)): ?>
	<p><center><?= $message ?></center></p>
	<?php endif; ?>
     </form>
    </div>
   </td>
  </tr>
 </table>
 <script src="frm.js"></script>
</body>
</html>
