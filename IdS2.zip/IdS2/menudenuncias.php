<?php

require 'BASE.php';

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <div class=".banner">
		<a href="http://localhost/IdS2/Denuncias.php"> <img src="pics\edomex.png" alt="Banner de mi página web"> </a>
	</div>
    <link rel="stylesheet" href="menudenuncias.css">
  </head>
<body>
<div class="grid-container">
  <div class="grid-item"><img src="pics\acolman.png"></div>
  <div class="grid-item"><img src="pics\amecameca.png"></div>
  <div class="grid-item"><img src="pics\coacalco.png"></div>
  <div class="grid-item"><img src="pics\cuatitlan.png"></div>
  <div class="grid-item"><img src="pics\chalco.png"></div>
  <div class="grid-item"><img src="pics\ecatepec.png"></div>
  <div class="grid-item"><img src="pics\huehuetoca.png"></div>
  <div class="grid-item"><img src="pics\ixtapaluca.png"></div>
  <div class="grid-item"><img src="pics\jaltenco.png"></div>
  <div class="grid-item"><img src="pics\ocampo.png"></div>
  <div class="grid-item"><img src="pics\metepec.png"></div>
  <div class="grid-item"><img src="pics\naucalpan.png"></div>
  <div class="grid-item"><img src="pics\neza.png"></div>
  <div class="grid-item"><img src="pics\romero.png"></div>
  <div class="grid-item"><img src="pics\teoti.png"></div>
  <div class="grid-item"><img src="pics\texcoco.png"></div>
</div>

</body>
</html>